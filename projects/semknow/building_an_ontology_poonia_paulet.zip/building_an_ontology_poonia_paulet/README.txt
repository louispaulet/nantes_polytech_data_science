Please find the documents from OutputDir in this UNCLOUD link (too big for the repository on extradoc) :

https://uncloud.univ-nantes.fr/index.php/s/JWJTR6cWfaarEti